# Django (Django)
# This folder contains assignments for Django and its subtopics. (Dieser Ordner enthält Aufgaben für Django und seine Unterthemen.)
