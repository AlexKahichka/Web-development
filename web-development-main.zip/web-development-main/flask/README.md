# Flask (Flask)
# This folder contains assignments for Flask. (Dieser Ordner enthält Aufgaben für Flask.)

